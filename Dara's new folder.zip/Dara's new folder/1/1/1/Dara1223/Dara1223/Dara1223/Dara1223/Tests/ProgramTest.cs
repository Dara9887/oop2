﻿using Dara1223;
using Xunit;
using System.IO;

namespace Dara1223.Tests
{
    public class ProgramTests
    {
        [Fact]
        public void SaveStatisticsToFile_ShouldSaveStatisticsToFile()
        {
            // Arrange
            var stats = new Statistics();
            stats.RegisterCorrectAnswer();
            stats.RegisterIncorrectAnswer();
            var filePath = Program.GetStatisticsFilePath();

            // Act
            Program.SaveStatisticsToFile(stats);
            var lines = File.ReadAllLines(filePath);

            // Assert
            Assert.Equal($"Games Played: {stats.GamesPlayed}", lines[0]);
            Assert.Equal($"Correct Answers: {stats.CorrectAnswers}", lines[1]);
            Assert.Equal($"Incorrect Answers: {stats.IncorrectAnswers}", lines[2]);
            File.Delete(filePath);
        }

        [Fact]
        public void ShowInstructions_ShouldShowInstructions()
        {
            using (StringWriter sw = new StringWriter())
            {
                Console.SetOut(sw);

                Program.ShowInstructions();

                string expected = "MathsTutor Instructions:\r\n" +
                                  "Choose the number of cards you want to play with (3 or 5).\r\n" +
                                  "The cards will have a number (1-13) and an operator (+, -, *, /).\r\n" +
                                  "Your goal is to calculate the correct answer using the given cards.\r\n" +
                                  "Enter '1' to play, '2' to show instructions, '3' to quit.\r\n" +
                                  "When playing, enter the number of cards you want to deal (3 or 5).\r\n" +
                                  "Enter '4' to save statistics to file, or '5' to load them from a file.\r\n";

                Assert.Equal(expected, sw.ToString());
            }

        }
    }
}