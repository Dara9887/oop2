﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace Dara1223.Tests
{
    public class SpecialCardTests
    {
        [Fact]
        public void GetNumber_ReturnsDoubleValue()
        {
            // Arrange
            var card = new SpecialCard(5, 1);

            // Act
            int result = card.GetNumber();

            // Assert
            Assert.Equal(10, result);
        }

        [Fact]
        public void GetOperator_ReturnsExponentiationSymbol_ForSuit1()
        {
            // Arrange
            var card = new SpecialCard(5, 1);

            // Act
            string result = card.GetOperator();

            // Assert
            Assert.Equal("^", result);
        }

        [Fact]
        public void GetOperator_ReturnsModulusSymbol_ForSuit2()
        {
            // Arrange
            var card = new SpecialCard(5, 2);

            // Act
            string result = card.GetOperator();

            // Assert
            Assert.Equal("%", result);
        }

        [Fact]
        public void GetOperator_ReturnsDefaultOperator_ForOtherSuits()
        {
            // Arrange
            var card = new SpecialCard(5, 3);

            // Act
            string result = card.GetOperator();

            // Assert
            Assert.Equal("*", result);
        }
    }
}