﻿using Dara1223;
using System;
using System.Collections.Generic;
using Xunit;
using Xunit.Abstractions;

namespace Dara1223.Tests
{
    public class PackTests : IDisposable
    {
        private readonly ITestOutputHelper _output;
        private readonly TextWriter _originalOut;
        private readonly TextReader _originalIn;

        public PackTests(ITestOutputHelper output)
        {
            _output = output;
            _originalOut = Console.Out;
            _originalIn = Console.In;
        }

        public void Dispose()
        {
            Console.SetOut(_originalOut);
            Console.SetIn(_originalIn);
        }

        [Theory]
        [InlineData("3 + 5", 8)]
        [InlineData("8 - 2", 6)]
        [InlineData("6 * 2", 12)]
        [InlineData("9 / 3", 3)]
        public void Test_CalculateExpression(string expression, double expected)
        {
            var statistics = new Statistics();
            var pack = new Pack(statistics);
            double result = pack.CalculateExpression(expression);
            Assert.Equal(expected, result, 1);
        }

        [Fact]
        public void Test_Handle3Cards()
        {
            var statistics = new Statistics();
            var pack = new Pack(statistics);

            using (StringWriter sw = new StringWriter())
            {
                Console.SetOut(sw);

                // Redirect the input as well to avoid the test waiting for input
                using (StringReader sr = new StringReader("0"))
                {
                    Console.SetIn(sr);
                    pack.DealCards(3);
                }
            }

            Assert.Equal(3, pack.GetExpression().Split(' ').Length);
        }

        [Fact]
        public void Test_Handle5Cards()
        {
            var statistics = new Statistics();
            var pack = new Pack(statistics);

            using (StringWriter sw = new StringWriter())
            {
                Console.SetOut(sw);

                // Redirect the input as well to avoid the test waiting for input
                using (StringReader sr = new StringReader("0"))
                {
                    Console.SetIn(sr);
                    pack.DealCards(5);
                }
            }

            Assert.Equal(5, pack.GetExpression().Split(' ').Length);
        }
    }
}