﻿using Dara1223;
using System;

namespace Dara1223
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the MathsTutor Game!");

            var statistics = new Statistics();
            var pack = new Pack(statistics);

            while (true)
            {
                Console.WriteLine("1. Show instructions");
                Console.WriteLine("2. Deal 3 cards");
                Console.WriteLine("3. Deal 5 cards");
                Console.WriteLine("4. Save statistics to file");
                Console.WriteLine("5. Quit");

                try
                {
                    int choice = Convert.ToInt32(Console.ReadLine());

                    switch (choice)
                    {
                        case 1:
                            ShowInstructions();
                            break;
                        case 2:
                            DealCards(pack, 3);
                            break;
                        case 3:
                            DealCards(pack, 5);
                            break;
                        case 4:
                            SaveStatisticsToFile(statistics);
                            break;
                        case 5:
                            Console.WriteLine("Thank you for playing the MathsTutor Game! Goodbye!");
                            return;
                        default:
                            Console.WriteLine("Invalid choice. Please try again.");
                            break;
                    }
                }
                catch (FormatException)
                {
                    Console.WriteLine("Invalid input. Please enter a number.");
                }
            }
        }

        public static void ShowInstructions()
        {
            Tutorial.ShowInstructions();
        }

        public static void DealCards(Pack pack, int count)
        {
            pack.DealCards(count);
        }

        public static void SaveStatisticsToFile(Statistics statistics)
        {
            string filePath = "statistics.txt";
            statistics.SaveToFile(filePath);
            Console.WriteLine($"Statistics saved to {filePath}");
        }

        // Add this method inside the Program class
        public static string GetStatisticsFilePath()
        {
            return "statistics.txt";
        }
    }
}