﻿using System.IO;
using Xunit;

namespace Dara1223.Tests
{
    public class StatisticsTests
    {
        [Fact]
        public void RegisterCorrectAnswer_IncrementsCorrectAnswersAndGamesPlayed()
        {
            // Arrange
            var stats = new Statistics();

            // Act
            stats.RegisterCorrectAnswer();

            // Assert
            Assert.Equal(1, stats.GamesPlayed);
            Assert.Equal(1, stats.CorrectAnswers);
            Assert.Equal(0, stats.IncorrectAnswers);
        }

        [Fact]
        public void RegisterIncorrectAnswer_IncrementsIncorrectAnswersAndGamesPlayed()
        {
            // Arrange
            var stats = new Statistics();

            // Act
            stats.RegisterIncorrectAnswer();

            // Assert
            Assert.Equal(1, stats.GamesPlayed);
            Assert.Equal(0, stats.CorrectAnswers);
            Assert.Equal(1, stats.IncorrectAnswers);
        }

        [Fact]
        public void SaveToFile_WritesStatisticsToFile()
        {
            // Arrange
            var stats = new Statistics();
            stats.RegisterCorrectAnswer();
            stats.RegisterIncorrectAnswer();
            var filePath = "Daras statistics";

            // Act
            stats.SaveToFile(filePath);

            // Assert
            Assert.True(File.Exists(filePath));
            string[] lines = File.ReadAllLines(filePath);
            Assert.Equal($"Games Played: {stats.GamesPlayed}", lines[0]);
            Assert.Equal($"Correct Answers: {stats.CorrectAnswers}", lines[1]);
            Assert.Equal($"Incorrect Answers: {stats.IncorrectAnswers}", lines[2]);
            File.Delete(filePath);
        }

        [Fact]
        public void SaveToFile_HandlesException()
        {
            // Arrange
            var stats = new Statistics();
            var filePath = "nonexistent_directory\\Daras statistics";

            // Act
            stats.SaveToFile(filePath);

            // Assert
            // The method should handle the exception and write an error message to the console, so there is no assertion needed.
        }
    }
}