﻿using Dara1223;
using System;
using Xunit;

namespace Dara1223.Tests
{
    public class CardTests
    {
        [Fact]
        public void GetNumber_ReturnsValue()
        {
            // Arrange
            int value = 5;
            int suit = 2;
            Card card = new Card(value, suit);

            // Act
            int result = card.GetNumber();

            // Assert
            Assert.Equal(value, result);
        }

        [Theory]
        [InlineData(1, "+")]
        [InlineData(2, "-")]
        [InlineData(3, "*")]
        [InlineData(4, "/")]
        public void GetOperator_ReturnsOperator(int suit, string expectedOperator)
        {
            // Arrange
            int value = 5;
            Card card = new Card(value, suit);

            // Act
            string result = card.GetOperator();

            // Assert
            Assert.Equal(expectedOperator, result);
        }

        [Fact]
        public void GetOperator_ThrowsArgumentException_ForInvalidSuit()
        {
            // Arrange
            int value = 5;
            int invalidSuit = 5;
            Card card = new Card(value, invalidSuit);

            // Act & Assert
            Assert.Throws<ArgumentException>(() => card.GetOperator());
        }
    }
}

