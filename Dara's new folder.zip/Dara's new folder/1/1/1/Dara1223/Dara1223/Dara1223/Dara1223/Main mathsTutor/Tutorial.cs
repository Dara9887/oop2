﻿using Dara1223;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dara1223
{
    public static class Tutorial
    {
        public static void ShowInstructions()
        {
            Console.WriteLine("MathsTutor Instructions:");
            Console.WriteLine("Choose the number of cards you want to play with (3 or 5).");
            Console.WriteLine("The cards will have a number (1-13) and an operator (+, -, *, /).");
            Console.WriteLine("Your goal is to calculate the correct answer using the given cards.");
            Console.WriteLine("Enter '1' to play, '2' to show instructions, '3' to quit.");
            Console.WriteLine("When playing, enter the number of cards you want to deal (3 or 5).");
            Console.WriteLine("Enter '4' to save statistics to file, or '5' to load them from a file.");
        }
    }
}